<?php
if (!defined("ABSPATH")) {
    exit();
}
?>
<li><?php esc_html_e("More Addons...", "wpdiscuz"); ?></li>